package com.project.demo.item;

import java.util.List;

import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface ItemRepository extends CrudRepository<Item,String>{


	 @AllowFiltering
	   List<Item> findByName(String name);
	 
//	  @Query("SELECT * FROM customer WHERE age > ?0 ALLOW FILTERING")
//	  public List<Item> findCustomerHasAgeGreaterThan(int age);

}
