package com.project.demo.item;


import java.sql.Blob;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Table(value = "item")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Item {

	@PrimaryKey
	private int id;
	private String name;
	private int price;
	private Blob images;
	
	public Item() {}

	public Item(int id, String name, int price,Blob images) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.images=images;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getname() {
		return name;
	}

	public void setItem_name(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Item [id=" + id + ", name=" + name + ", price=" + price + "]";
	}

	public Blob getImages() {
		return images;
	}

	public void setImages(Blob images) {
		this.images = images;
	}

	
	
	
	
}
