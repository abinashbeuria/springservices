package com.project.demo.item;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.datastax.driver.core.ResultSet;




@RestController
public class ItemController  {

	@Autowired
	private ItemRepository itemRepository;
	
	@PostConstruct
	public void saveItem() {
		// TODO Auto-generated method stub
		Item item_1 = new Item(1, "gold", 20,);
		Item item_2 = new Item(2, "bike", 30,"");
		Item item_3 = new Item(3, "soap", 40,"");
		Item item_4 = new Item(4, "brush", 50,"");
		Item item_5 = new Item(5, "paste", 60,"");
		Item item_6 = new Item(6, "rice", 70,"");
		
//		itemRepository.findAll()
//		ResultSet rs = stmt.executeQuery("select images from item where id=1 ");  
//		java.sql.Blob blob = rs.getBlob(column);  
//		InputStream in = blob.getBinaryStream();  
//		BufferedImage image = ImageIO.read(in);
		itemRepository.save(item_1);
		 itemRepository.save(item_2);
		 itemRepository.save(item_3);
		 itemRepository.save(item_4);
		 itemRepository.save(item_5);
		 itemRepository.save(item_6);
	}
	
	@GetMapping("/FindByName/{name}")
	public List<Item> findByName(@PathVariable String name) {
		return itemRepository.findByName(name);
	}
	@GetMapping("getAllItems")
	public Iterable<Item> getItems() {
		return itemRepository.findAll();
	}
}
